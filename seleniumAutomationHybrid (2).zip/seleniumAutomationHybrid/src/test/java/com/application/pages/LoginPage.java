package com.application.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.selenium.TestcontextSetup.testContext;

import io.cucumber.java.Before;


public class LoginPage {

	private WebDriver driver;

	/*LOCATORS TO THE APPLICATION*/
	
	By username = By.id("username_id");
	By password =  By.id("password");
	By loginButton = By.id("login");
	
	
	
	public LoginPage(testContext t) {
		// TODO Auto-generated constructor stub
		this.driver = t.driver;
	}

	
	public void SignIntoApplication() {
		
		System.out.println("Session IDs for thr Drievr  ********>"+((ChromeDriver) driver).getSessionId().toString());
		driver.get("https://healthapp.yaksha.com/Account/LicenseExpired");
		driver.findElement(username).sendKeys("admin");
		driver.findElement(password).sendKeys("pass123");
		driver.findElement(loginButton).click();
	}
	
	
	
	
	
	
	
}
