package com.application.hooks;

import com.application.pages.LoginPage;
import com.selenium.TestcontextSetup.testContext;
import com.selenium.WebDriverManager.BrowserManager;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;

public class HooksClass {
	
	LoginPage logpg;
	testContext t;
	
	public HooksClass(testContext t) {
		
		if (t==null)
			this.t = t;
		
		if(logpg == null)
			logpg = new LoginPage(t);
	}
	
	@Before
	public void launchApplication() {
		logpg.SignIntoApplication();
	}
	
	
	@After
	public void exitApplication() {
		System.out.println("Each report scenario getting flusehd in reoprt");
	}
	
	@AfterAll
	public static void quitBrowserCompletely() {
		System.out.println("Quit method called this time");
		BrowserManager.quitDriver();
	}

}
