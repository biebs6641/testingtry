package com.app.runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


	
	
	@CucumberOptions(
			
			features = {"src/test/resources"},
			glue= {"com.application.Stepdefinition","com.application.hooks"},
			monochrome =  false,
			plugin = {"pretty"},
			dryRun = false
			
			)

	public class RunnerFile extends AbstractTestNGCucumberTests{

		@Override
		@DataProvider(parallel = true)
		public Object[][] scenarios() {
			return super.scenarios();
		}
		
		
	

}
	

