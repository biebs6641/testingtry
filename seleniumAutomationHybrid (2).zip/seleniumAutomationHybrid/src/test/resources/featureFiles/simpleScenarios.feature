Feature: Login into Page
  I want to use this template for my feature file

  @tag1
  Scenario: Title of your scenario
    Given I want to write a step with precondition
    
  @tag1
  Scenario: Title of your scenario
    Given I want to write a step with precondition
    
   
   @tag1
  Scenario: Title of your scenario
    Given I want to write a step with precondition
    
   @tag1
  Scenario: Title of your scenario
    Given I want to write a step with precondition