package com.selenium.WebDriverManager;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserManager {

	private static final Map<String, Supplier<WebDriver>> getBrowser = new LinkedHashMap<>();
	private static final ThreadLocal<WebDriver> driverStore = new ThreadLocal<>();

	private static final Supplier<WebDriver> chromBrowser = () -> {

		ChromeOptions op = new ChromeOptions();
		op.addArguments("--start-maximized");
		WebDriverManager.chromedriver().setup();
		driverStore.set(new ChromeDriver(op));
		return driverStore.get();

	};

	private static final Supplier<WebDriver> edgeBrowser = () -> {
		WebDriverManager.edgedriver().setup();
		EdgeOptions options = new EdgeOptions();
		options.addArguments("--start-maximized"); // Maximize browser
		options.addArguments("--disable-popup-blocking");
		driverStore.set(new EdgeDriver(options));
		return driverStore.get();

	};

	static {

		getBrowser.put("chrome", chromBrowser);
		getBrowser.put("edge", edgeBrowser);
	}

	public static WebDriver getDriver(String browser) {

		if (driverStore.get() == null) {

			driverStore.set(getBrowser.get(browser).get());
		}

		return driverStore.get();

	}

	/*
	 * Browser quit
	 */
	public static void quitDriver() {

		System.out.println("1. I entered in quitDriver");
//		WebDriver driver = driverStore.get();

		System.out.println(
				"Session IDs for thr Drievr  ********>" + ((ChromeDriver) driverStore.get()).getSessionId().toString());

		if (driverStore.get() != null) {
			System.out.println("2. I entered in quitDriver If statment");
			driverStore.get().quit();
			driverStore.remove();
		}

	}

}
