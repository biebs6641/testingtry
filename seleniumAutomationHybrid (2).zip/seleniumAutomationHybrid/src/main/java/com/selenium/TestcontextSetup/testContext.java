package com.selenium.TestcontextSetup;

import org.openqa.selenium.WebDriver;

import com.selenium.WebDriverManager.BrowserManager;

public class testContext {

	public WebDriver driver;

	public testContext() {
		// TODO Auto-generated constructor stub
		if (driver == null) {
			driver = BrowserManager.getDriver("chrome");
		}
	}

}
